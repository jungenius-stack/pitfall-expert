---
AIGC:
  Label: '1'
  ContentProducer: '001191110108MA01KP2T5U00000'
  ProduceID: '81835529995124279a87a4882832736c27113812ebfb3b628bdacc19077c8aa56ccfc6a0a4ce8079f39d6789022a07db66b5cb32e94e90fcca63b11b69f293658a93e467cb39d92797338a7c36c2fe5264965ae61ac43573c41344fb13119a72c1eaf9ed9ed5cfcfc4a143cd156ca0472f6cd69a40c93246d8d40f92d7ce4f420e90ff31a94285f28606410f912804e945086a98d5aa6a3437b46ab5a5e5eb07ee7d4c73339b17170e2467cf497e6667f5203f7a5a63fd908b65d3ff96f89ab3c3fa3d4eb01327681ae3155754de178d9cf6f70f96c83b8be0c90ffdc5fc3896a565d11643e1f17fbb9bbf612f6efe31'
  ReservedCode1: '4a206b70958062c0a392851adfc984a6933c10558e1b1b3666e72b7f8075eddf25652c1d93bf0dca3efd9bd7936fcea1c83592a6f7c6148f718a2f4a5794bbad'
  ContentPropagator: '001191110108MA01KP2T5U00000'
  PropagateID: '81835529995124279a87a4882832736c27113812ebfb3b628bdacc19077c8aa56ccfc6a0a4ce8079f39d6789022a07db66b5cb32e94e90fcca63b11b69f293658a93e467cb39d92797338a7c36c2fe5264965ae61ac43573c41344fb13119a72c1eaf9ed9ed5cfcfc4a143cd156ca0472f6cd69a40c93246d8d40f92d7ce4f420e90ff31a94285f28606410f912804e945086a98d5aa6a3437b46ab5a5e5eb07ee7d4c73339b17170e2467cf497e6667f5203f7a5a63fd908b65d3ff96f89ab3c3fa3d4eb01327681ae3155754de178d9cf6f70f96c83b8be0c90ffdc5fc3896a565d11643e1f17fbb9bbf612f6efe31'
  ReservedCode2: '4a206b70958062c0a392851adfc984a6933c10558e1b1b3666e72b7f8075eddf25652c1d93bf0dca3efd9bd7936fcea1c83592a6f7c6148f718a2f4a5794bbad'
---
# LLM-as-Judge评判可靠性与一致性：偏差实证、Rubric设计、校准方法与反思技术的系统综述

## 摘要

大语言模型作为裁判（LLM-as-a-Judge）的评估范式旨在弥合传统自动评分与人类判断之间的评估鸿沟。本报告系统综述该范式在评判可靠性与一致性方面的研究进展，涵盖系统性偏差实证、Rubric设计、校准方法与反思去偏技术四个维度，基于多源文献检索与综合分析路径展开。主要发现包括：位置偏差、冗长偏差、自偏好偏差和同意偏差等系统性偏差普遍存在但表现出强任务与模型依赖性；原子化Rubric设计可降低评分方差，但Rubric文本本身可能携带与评判结果耦合的预测信号；校准方法从提示工程演化为分布对齐与不确定性量化，过度自信现象普遍且严重；Meta-Judge范式受共享模型偏差制约，多层反思主要检查内部一致性而非真值。核心结论指出，LLM-as-a-Judge的可靠性提升需要偏差诊断、准则设计、校准信号与反思机制的协同推进，单一维度的优化不足以根本解决评判可靠性问题。

## 关键词

LLM-as-a-Judge、系统性偏差、Rubric设计、校准方法、反思技术、评估可靠性、去偏差策略

## 全文知识地图

![图](images/figure_1.png)

**图 1：本图以偏差实证、Rubric设计、人类校准与反思去偏四条主线串联全文知识脉络**

## 引言

生成式AI的快速发展使评估范式从传统自动评分向模型驱动评判深刻转变。BLEU和ROUGE等基于表面相似度的指标在复杂生成任务中与人类判断的相关性较弱，而人类同行评审虽质量较高却受限于成本与速度。LLM-as-a-Judge范式的兴起正是对这一评估鸿沟的直接回应——利用大语言模型对生成文本进行自动化评估与打分，在成对比较中与人类评估者达到约80%一致率，奠定了该范式的研究基础 [[1](https://www.aminer.cn/pub/6424fe3390e50fcafd78b6f4)]。然而，评估主体与被评估对象可能属于同一模型家族甚至同一模型实例，由此产生的自引用和自偏好问题使评判可靠性面临根本性挑战。

随着研究的深入，评判可靠性的多重威胁逐步浮现。位置偏差在成对比较中因候选答案呈现位置不同而产生系统性偏好，且在模型能力接近的高风险评估场景中影响最为严重 [[2](https://www.aminer.cn/pub/66b18cbe01d2a3fbfc7bd09e)]。冗长偏差的根因分析表明，响应长度通过影响信息量来影响评估结果，而长度与质量之间的关联在某些任务中可能并非完全虚假 [[3](https://www.aminer.cn/pub/66835f4601d2a3fbfc717fd7)]。自偏好偏差的量化框架揭示了评判模型对低困惑度文本的偏好倾向，而同意偏差则暴露了评判模型在识别错误输出方面的严重缺陷 [[4](https://www.aminer.cn/pub/68eeef5e163c01c850f75191)]。在干预层面，Rubric设计从思维链提示演化至原子化二元判断 [[5](https://www.aminer.cn/pub/67ce4b40163c01c850b7d2e7)]，校准方法从人类纠正的对齐循环拓展至分布对齐与不确定性量化 [[6](https://www.aminer.cn/pub/691d6d0e163c01c850879bad)]。

然而，前人研究仍存在若干尚未解决的问题与空白。首先，系统性偏差的方向、强度和表现形式高度依赖具体任务和模型组合，通用去偏策略的设计面临根本性挑战。其次，Rubric文本本身可能携带与评判结果耦合的预测信号，这一"Rubric Artifacts"现象对原子化rubric设计的有效性构成了潜在质疑 [[7](https://arxiv.org/html/2609.02942v1)]。第三，Meta-Judge范式受共享模型偏差制约，多层反思主要检查内部一致性而非真值 [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。此外，多模态评判、跨模型家族的多智能体协同以及系统级成本约束等方向尚未得到系统性实证支撑。

基于上述背景与空白，本报告旨在系统综述LLM-as-a-Judge在评判可靠性与一致性方面的研究进展，围绕系统性偏差实证、Rubric设计、校准方法与反思技术四个核心维度构建完整的论证链条。报告依次展开五章论述：第1章完成概念界定与研究图景勾勒，第2章系统梳理位置偏差、冗长偏差和自偏好偏差等偏差类型、量化框架与根因争议，第3章聚焦Rubric设计从提示工程到形式化规范的演进及其内在张力，第4章转向校准方法与人类对齐，第5章收束于反思自洽与多策略去偏的系统比较并指出开放挑战。

## 1. 概念界定与研究图景

### 1.1 LLM-as-a-Judge概念界定与范畴辨析

大语言模型的评估范式经历了从传统自动评分到模型驱动评判的深刻转变。在生成式AI快速发展的背景下，评估文本质量的核心挑战从"生成是否语法正确"转向"生成是否对齐人类偏好与任务意图"。传统指标如BLEU和ROUGE基于表面文本相似度，在复杂生成任务中与人类判断的相关性较弱。LLM-as-a-Judge（大模型作为裁判）范式的兴起，正是对这一评估鸿沟的直接回应。该范式的权威定义可概括为：利用大语言模型对另一AI应用或模型生成的自然语言文本进行自动化评估与打分的评估范式，其核心关注点在于评判结果的可靠性、无偏性及与人类判断的一致性。

在范畴辨析层面，需明确LLM-as-a-Judge与传统自动评分及人类同行评审的本质区别。传统自动评分依赖规则或小模型，在限定领域内通过精确匹配或浅层语义匹配完成打分，缺乏对开放式生成任务的泛化能力。人类同行评审虽能提供高质量判断，但受限于成本、速度和标注者间一致性（inter-rater agreement）等固有瓶颈。LLM-as-a-Judge介于二者之间：以LLM本身作为评估主体，评估对象为生成文本，评估方式涵盖成对比较（pairwise comparison）、标准评分（criteria-based scoring）和参考比对（reference-based evaluation）等多种形式。其独特之处在于，评估主体与被评估对象可能属于同一模型家族甚至同一模型实例，由此产生的自引用和自偏好问题构成了本报告后续章节的核心议题之一。

值得注意的是，LLM-as-a-Judge并非单一技术，而是一个包含提示设计、评估准则构造、置信度量化和后校准在内的系统性评估框架。在该框架中，评判模型（judge model）通常通过结构化提示接收待评估文本及评估标准，输出评分或偏好排序。关键的设计决策包括评判模型的选择（强模型还是轻量模型）、评估形式的确定（单点评分还是成对比较）、以及评估标准的来源（人类预定义还是模型自生成）。这些设计决策直接影响评判的可靠性与一致性，也是本报告各章节展开讨论的基础。

### 1.2 关键术语与评估维度

LLM-as-a-Judge研究涉及一组相互关联但需严格区分的核心术语。评分漂移指的是评判模型在多次评估或不同评估设置下产生的评分系统性偏移现象，这种偏移可能源于提示措辞变化、模型版本更新或评估条件微调。对齐循环是指通过持续收集人类纠正信号来系统校准评判模型与人类判断一致性的迭代工作流，强调提示迭代本身不足以弥合技术正确与可靠可信之间的差距。评估准则产物指评估标准文本本身可能编码与评判结果耦合的可预测信号，即rubric的表述方式可能独立于被评估内容影响评判输出。位置偏差是评判模型在成对比较中因候选答案呈现位置不同而产生系统性偏好倾向的现象。人类基准真值指由人类专家标注的评估结果，作为衡量LLM judge可靠性的参照标准。

在评估维度上，LLM-as-a-Judge的可靠性可从三个层面度量。第一是可靠性，即评判结果在相同输入下的可重复性和稳定性，包括同一模型多次运行的一致性以及跨提示设置的一致性。第二是无偏性，指评判结果不受候选答案位置、长度、风格、来源等非质量因素系统性影响的程度。第三是一致性，主要关注评判结果与人类专家判断的对齐程度，通常通过相关系数、一致率或Cohen's κ等指标量化。这三个维度并非独立：无偏性是可靠性的前提，而一致性是可靠性和无偏性在人类判断维度的投影。本报告后续章节将围绕这三个维度展开实证分析与技术干预的讨论。

生成-评估一致性这一概念为理解评估能力与人类偏好对齐之间的关系提供了理论桥梁。研究发现在多种LLM间，当由强LLM偏好预言机评估时，LLM的生成和评估能力之间存在强相关 [[9](https://www.aminer.cn/pub/691d6b2f163c01c85085f952)]。这一发现具有重要的方法论意义：如果LLM的判断能力与其生成能力高度相关，那么可以通过评估其作为judge的表现来间接推断其对齐水平。然而需注意，该概念为间接度量——评估能力与生成能力的相关性并不意味着评估能力本身已达到可靠水平，而是提供了一个诊断对齐状态的新视角。这一发现也为对齐循环的校准实践提供了理论支撑：校准judge与人类的一致性不仅是评估质量问题，更是对齐本身的重要度量。

### 1.3 研究脉络与本文组织

LLM-as-a-Judge的研究脉络呈现出从概念验证到偏差诊断、从准则优化到系统校准、从单一评判到多层反思的递进结构。早期的开创性工作如MT-Bench和Chatbot Arena验证了强LLM作为评判者在成对比较中与人类评估者达到约80%一致率的可行性，奠定了该范式的研究基础。随后，研究者逐步揭示了评判可靠性的多重威胁：位置偏差、冗长偏差、自偏好偏差和同意偏差等系统性偏差在不同任务和模型上的表现各异，且偏差之间可能存在交互作用。在偏差诊断的基础上，研究界从两个方向展开干预：一是从评估准则设计层面预防偏差，通过原子化rubric、实例级checklist和形式化规范约束评判行为；二是从事后校准层面纠正偏差，通过人类纠正信号注入、分布对齐训练和不确定性度量提升评判与人类判断的一致性。

本报告沿此脉络展开五章论述。第1章完成概念界定与框架勾勒，为读者建立统一认知锚点。第2章系统梳理位置偏差、冗长偏差和自偏好偏差等系统性偏差的实证发现、量化框架与根因争议，构建全文实证基础。第3章聚焦Rubric设计这一关键干预手段，辨析形式化规范与"捷径效应"之间的张力。第4章转向校准方法与人类对齐，从对齐循环到分布对齐与不确定性度量。第5章收束于反思自洽与多策略去偏的系统比较，并指出多模态评判、多智能体协同等开放挑战。需要指出的是，评判的可靠性受多重系统性偏差威胁，这一判断贯穿全文，各章在偏差实证、准则设计、校准方法和反思技术之间形成层层递进的论证链条。

## 2. 系统性偏差的实证研究：类型、量化与机制

### 2.1 位置偏差：多维度框架与高风险领域实证

位置偏差是LLM-as-a-Judge中被最早识别且研究最为深入的系统性偏差之一。在成对比较评估中，评判模型可能因候选答案的呈现位置不同而系统性偏好某一位置，这种偏好与答案本身的质量无关，却可能严重扭曲评估结论。Shi等人在ICLR 2025上发表的工作为位置偏差研究提供了迄今最系统的理论框架，引入了三个互补维度来刻画位置偏差的全貌：重复稳定性衡量同一排序下多次调用结果的一致性，位置一致性衡量交换候选位置后结果的一致性，偏好公平性则检验是否因位置而系统性偏向某一候选 [[2](https://www.aminer.cn/pub/66b18cbe01d2a3fbfc7bd09e)]。该框架的实验规模庞大——12个LLM评判器在MTBench和DevBench上覆盖22个任务和约40个候选模型，产生超过100,000个评估实例——使其结论具有强统计效力。

该框架的关键发现深化了对位置偏差本质的理解。首先，有能力LLM评判器的位置偏差并非随机产生，而是系统性的，这一结论排除了将位置偏差简单归因于采样随机性的可能。其次，不同评判器和任务间偏差差异显著，提示位置偏差的表现具有任务依赖性和模型依赖性。第三，位置偏差受提示组件长度影响较弱，但受候选解之间质量差距的显著影响——当质量差距小时位置偏差更严重 [[2](https://www.aminer.cn/pub/66b18cbe01d2a3fbfc7bd09e)]。这一发现具有重要的实践含义：在模型能力接近的对比场景中（如前沿模型之间的排行榜评估），位置偏差对排名的影响最为严重，恰恰是这些场景对评估公正性的要求最高。

位置偏差的研究意义在高风险实际应用场景中得到进一步验证。在招聘评估领域，研究者使用Llama 3 70B对219份真实简历进行评估，每份简历在50人列表中的5个位置出现，产生1,097个评分。单因素方差分析显示位置对评分有显著影响（$F(4, 1072)=31.12$, $p<0.001$），且列表长度可改变偏差方向 [[10](https://www.aminer.cn/pub/6abafb6225ef7be5fbbf08dd)]。这一结果在招聘这一对公平性高度敏感的领域中具有直接的现实危害：简历的列表位置可能系统性地影响候选人的被评估结果，而传统的人类评估流程中这一偏差可能被不同的机制所缓解。

医疗分诊场景的研究则揭示了一种与直觉相反的位置偏差模式。使用GPT-4o和GPT-4o mini进行多人伤亡分诊实验，研究发现一致的近因偏差：最重伤员排在第一位时更可能不被优先处理，且该效应在较短患者列表中更明显 [[11](https://www.aminer.cn/pub/699d226e9be8eb7c4b17e971)]。这一发现挑战了"短提示不易产生位置偏差"的常见假设。在紧急医疗分诊这一时间敏感且后果严重的场景中，位置偏差可能导致最需要救治的患者被延迟处理，构成了对LLM-as-a-Judge在高风险领域部署的直接警示。

位置偏差的表现并非在所有任务中都一致。在ChatGPT自动作文评分的研究中，使用192篇合成作文检验首因和近因效应，结果发现ChatGPT能区分强弱段落，但未发现系统性首因或近因效应的充分证据，评分模式基本平衡 [[12](https://www.aminer.cn/pub/69fc4f750a96f8c83c732015)]。这一结果表明位置偏差可能受任务类型、评分粒度和评估形式等因素调节，不能简单假定在所有场景中都存在相同模式的位置偏差。综合来看，位置偏差的实证研究揭示了一个核心张力：偏差的存在是系统性的，但偏差的方向、强度和表现形式高度依赖于具体任务和模型组合，这使得通用去偏策略的设计面临根本性挑战。

### 2.2 冗长偏差与长度偏差的机制分解与校准

冗长偏差指LLM评判者系统性地偏好更长响应的倾向，是影响评估公正性的另一核心偏差类型。与位置偏差不同，冗长偏差的根因更为隐蔽——长度本身可能确实与回答质量相关（更长的回答可能包含更多信息），因此偏差与合理偏好之间的界限难以简单划定。Hu等人在EMNLP 2025上的工作为解决这一概念难题提供了关键的理论突破，其核心创新在于将偏好评估指标（特别是胜率）分解为两个关键组件：期望度，与长度无关，与正确性、毒性、一致性等可信度维度相关；信息量，长度依赖，代表响应中的信息总量 [[3](https://www.aminer.cn/pub/66835f4601d2a3fbfc717fd7)]。通过控制实验证明，响应长度通过影响信息量来影响评估结果，这一分解使"长度导致的偏差"与"长度反映的质量差异"得以在概念上分离。

基于这一分解，该研究提出AdapAlpaca方法——一种对胜率测量的简单有效调整，通过在等效长度区间内对齐参考模型和测试模型响应的长度来确保公平比较 [[3](https://www.aminer.cn/pub/66835f4601d2a3fbfc717fd7)]。这一方法的巧妙之处在于不需要修改评判模型本身，而是通过评估后处理消除长度维度的不公平比较条件。该工作被引53次，是冗长偏差领域最具影响力的工作之一，其理论框架为后续研究提供了共同的讨论基础。

在RLHF奖励建模层面，长度偏差的因果机制得到了进一步深入分析。Kim等人在AAAI 2026上提出因果框架分析RLHF奖励建模中的长度偏差，核心方法是反事实数据增强——生成隔离内容质量与冗长度的响应对，包括内容相似但长度不同的对和长度相似但内容不同的对 [[13](https://www.aminer.cn/pub/691bdbe1163c01c850d3cb74)]。用这些反事实例子训练奖励模型，使其独立于冗长度评估响应。这一方法从数据层面切断了长度与奖励之间的虚假关联，是对AdapAlpaca评估后处理策略的补充——前者从训练阶段预防偏差，后者从评估阶段校正偏差。

长度偏差的非线性特征是另一个重要发现。Zhao等人提出的FiMi-RM框架通过三阶段方法自主学习和纠正底层偏差模式：首先训练标准奖励模型预热，然后部署轻量拟合模型捕获长度-奖励间的非线性关系，最后将学到的关系整合到奖励模型中 [[14](https://www.aminer.cn/pub/682be3c4163c01c850f4a2de)]。这一发现表明长度偏差不是简单的线性偏移，而是可能随长度区间变化呈现不同的强度和方向。对DPO和BoN对齐算法应用去偏奖励模型改善了长度控制胜率并降低了冗长度，说明在奖励建模阶段纠正长度偏差可以产生下游的生成质量改善。

事后奖励校准为闭源模型场景提供了无需重新训练的解决方案。Huang等人在ICLR 2025上提出的事后奖励校准方法聚焦长度偏差，通过局部平均奖励估计偏差项并移除，在33个奖励模型上实现平均3.11的性能提升，且无需额外数据和训练，计算高效且可泛化到其他偏差类型 [[15](https://www.aminer.cn/pub/66f619a301d2a3fbfcdc604f)]。Zhou等人在2024年的工作中针对LLM-as-a-Judge偏差提出了更系统性的方案：对闭源评判模型在概率层面和提示层面进行校准以降低表面质量显著性，对开源评判模型通过构建偏离指令但表面质量更好的负样本进行对比训练 [[16](https://www.aminer.cn/pub/66f4cd3401d2a3fbfcbfab6c)]。这种区分闭源与开源模型的差异化策略反映了实际部署中的核心约束：闭源模型无法访问内部状态或进行参数微调，只能通过黑盒后处理缓解偏差；开源模型则可通过对比训练从根本上调整模型的偏差倾向。

综合来看，冗长偏差与长度偏差的研究揭示了偏差缓解的多层次方法谱系：从评估后处理（AdapAlpaca）到训练数据增强（反事实对）到奖励建模去偏（FiMi-RM）到事后校准（局部平均移除）。这些方法在干预阶段、适用模型类型和计算成本上各有侧重，但在概念上都共享一个核心假设：长度与质量之间的关联是虚假的，应被分离。然而，这一假设在某些任务中可能不完全成立——例如，需要详细解释的任务中更长的回答可能确实更高质量——这提示长度偏差的缓解需要考虑任务语义。

### 2.3 自偏好偏差的根因争议与同意偏差

自偏好偏差指LLM评判者系统性地偏好自身生成输出的倾向，这一偏差对使用强LLM作为通用评估器的实践构成了特殊风险：如果评判者偏好自身风格，那么排行榜评估可能成为特定模型风格偏好的放大器，而非客观质量排序。Wataoka等人在ICLR 2025上的开创性工作为自偏好偏差的量化提供了基于算法公平性的严谨框架。该研究借用Equal Opportunity的定义，通过比较LLM评估器对自己生成的响应与对其他模型生成响应的评分差异来衡量偏差，形式化定义为 $Bias=P(Y'=1|S=1,Y=1)-P(Y'=1|S=0,Y=1)$，其中 $Y$ 为人类偏好索引，$Y'$ 为评估器偏好索引，$S$ 为自身生成索引 [[17](https://www.aminer.cn/pub/672195e901d2a3fbfc6ab4b4)]。

在Chatbot Arena数据集（33,000个对话）上对8个LLM的实验揭示了显著的模型间差异。GPT-4表现出最高的自偏好偏差（偏差分数约0.52），其次是Vicuna-13b和Koala-13b。该研究深入探讨了偏差根因，假设LLM评估器可能受到文本困惑度的影响——自己生成的文本困惑度天然较低。分析证实，LLM评估器对低困惑度文本的评分显著高于人类评估器，且这种倾向与文本是否由自身生成无关 [[17](https://www.aminer.cn/pub/672195e901d2a3fbfc6ab4b4)]。这一发现的深层含义是：自偏好偏差的本质可能不在于模型"识别"了自身输出，而在于模型偏好更熟悉的文本（困惑度更低的文本），自身生成的文本恰好具有更低的困惑度。研究还发现，对GPT-4等先进模型而言，偏差往往不涉及事实错误，而是与响应风格差异相关，如处理专业领域的方式或回答前提的描述方式。

然而，对自偏好偏差根因的解释存在不同观点。Yang等人在2026年的预印本工作中提出了另一种缓解思路——基于认知负荷分解的结构化多维度评估策略。该框架通过构建质量差异可忽略的等质量回答对，在无人类金标准的条件下统计分离判别力与偏差倾向，跨20个主流LLM的实证分析揭示：先进模型能力往往与低自偏好偏差不相关甚至负相关 [[18](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31a4d)]。基于认知负荷分解的策略将复杂评估任务分解为多个认知维度，降低单一维度上的自我偏好表达空间，平均降低自偏好偏差31.5%。这一方法的有效性暗示自偏好偏差可能部分源于评估任务本身的复杂性——当评估任务过于笼统时，评判模型可能退回到对自身输出风格的默认偏好；当评估被分解为具体的认知维度后，这种默认偏好的表达空间被压缩。

两种根因解释之间存在潜在的矛盾但并非不可调和。困惑度根因说强调偏差源于模型对低困惑度文本的偏好，这是一种自下而上的统计性解释；认知负荷分解的有效性则暗示偏差部分源于评估任务设计的粗糙，这是一种自上而下的任务结构解释。可能的调和是：低困惑度偏好是底层机制，但当评估任务被结构化分解后，评判模型的注意力被引导至具体质量维度，低困惑度偏好的影响被稀释。这一假说需要进一步的对照实验验证——例如，在认知负荷分解条件下测量评判结果与文本困惑度之间的相关性是否降低。

自偏好偏差在rubric评估范式下的持续性是另一个重要发现。Pombal等人在COLM 2026上的研究首次考察了rubric评估范式下的自偏好偏差，使用IFEval和LiveCodeBench（具有可编程验证rubric的基准），发现即使在完全客观的评估标准下自偏好偏差仍然持续：在生成模型失败的rubric中，评判器对自己输出的错误标记为满足的可能性比其他输出高50%以上 [[19](https://www.aminer.cn/pub/69d6f9de9be8eb7c4b04628c)]。在HealthBench（主观rubric的医学聊天基准）上，自偏好偏差使模型分数偏移高达10分——在前沿模型排名中可能是决定性差距。研究发现负面rubric和主观主题（如沟通和紧急转诊）尤其容易产生自偏好偏差，多评判器集成有助于缓解偏差但无法完全消除。这一发现说明自偏好偏差不仅存在于自由评估场景，即使提供了客观可验证的评估标准也难以完全消除，提示偏差的根因可能深植于模型的训练过程而非评估设置。

同意偏差构成了与自偏好偏差相关但机制不同的另一类偏差。Jain等人在ICLR 2026上量化了一种被称为"同意偏差"的系统性偏差：LLM judge在识别正确输出方面表现优异（真阳性率 > 96%），但在识别错误输出方面表现极差（真阴性率 < 25%）[[4](https://www.aminer.cn/pub/68eeef5e163c01c850f75191)]。实验使用14个LLM作为验证器评估6个生成器在366个高中Python程序反馈任务上的输出。这种低真阴性率被高真阳性率和类别不平衡（仅约7.5%无效输出）所掩盖，导致整体精度被高估。这一发现的方法论意义在于：即使在整体精度看似可接受的评估中，评判模型对错误输出的识别能力可能严重不足，而这一缺陷在标准精度指标下是不可见的。该研究提出的回归校正框架利用少量人类标注数据校准每个验证器的真阳性率和真阴性率，仅用5个标注数据集校准即可将最大绝对误差降至1.2%，比最佳集成方法改善2倍 [[4](https://www.aminer.cn/pub/68eeef5e163c01c850f75191)]。关键洞见是：即使Elo排名最高的模型也可能有很低的真阴性率，Elo排名不足以选择可靠的验证器——这一结论对当前以Elo排名为主要模型选择依据的实践构成了直接挑战。

在跨偏差类型的联合去偏方面，Yang等人在NeurIPS 2025上提出的RBD（Reasoning-based Bias Detector）框架代表了重要进展。RBD是一个即插即用模块，通过识别有偏评估并生成结构化推理来引导评估器自我纠正，不修改评估器本身而是外部运行于迭代过程中进行偏差检测和反馈驱动修订 [[20](https://www.aminer.cn/pub/6833ca05163c01c8505ea141)]。该框架覆盖四种偏差类型——冗长偏差、位置偏差、bandwagon偏差和情感偏差——并在8个LLM评估器上验证。RBD-8B模型平均提升评估准确率18.5%、一致性10.9%，分别超越基于提示的基线和微调评判器12.8%和17.2%。该工作的重要意义在于：克服了上下文学习方法的自我反思能力限制，适用于闭源模型（无需微调评估器本身），并展示了跨偏差类型和跨领域的强泛化能力。这一框架为偏差缓解既需要事后去偏、也需要从评估准则设计层面预防的判断提供了直接支撑——如本章各节所示，单一偏差类型的缓解策略已面临任务依赖性和模型依赖性的挑战，多偏差联合去偏的框架化路径可能是更具实践价值的发展方向。

## 3. Rubric设计与优化：从提示工程到形式化规范

### 3.1 从CoT提示到分层分解：Rubric优化的两条路径

评估准则的设计质量直接决定LLM-as-a-Judge评判结果的可靠性与一致性。早期的rubric优化研究沿两条路径展开：一是通过更优的提示策略提升rubric应用质量，二是通过标准的层级分解和人类偏好对齐优化rubric本身的结构。G-Eval（EMNLP 2023，被引2485次）代表了第一条路径的开创性尝试，其核心方法是通过思维链提示和表单填充范式来评估NLG输出质量 [[1](https://www.aminer.cn/pub/6424fe3390e50fcafd78b6f4)]。G-Eval使用GPT-4作为骨干模型，在文本摘要任务上达到与人类的Spearman相关系数0.514，大幅超越此前所有方法。这一工作的贡献不仅在于具体的提示技术，更在于确立了"通过提示工程改善rubric应用"的研究范式——评估质量可以通过设计更优的评估提示来系统提升。G-Eval还揭示了LLM评估器对LLM生成文本存在偏好的问题，这一发现为后续的自偏好偏差研究提供了早期的实证线索。

HD-Eval（ACL 2024）则转向第二条路径，通过分层标准分解迭代对齐LLM评估器与人类偏好 [[21](https://www.aminer.cn/pub/65dd4f8013fb2c6cf66f9dfd)]。其方法包括将给定评估任务分解为更细粒度的标准，根据估计的人类偏好聚合这些标准，通过归因分析剪枝不重要的标准，进一步分解重要的标准，整个过程在迭代对齐训练中完成。HD-Eval的聚合器是白盒的、可解释的，且不依赖模型参数使其适用于闭源LLM。在三个评估领域的实验证明了HD-Eval能进一步对齐最先进的评估器。与G-Eval侧重提示优化不同，HD-Eval侧重于标准本身的层级结构和人类偏好对齐——它假设粗粒度的评估标准是评判不一致的根源，通过迭代分解和剪枝使标准逐步精细化并与人类判断对齐。

这两种方法代表了rubric优化的不同策略基座。G-Eval的路径假设评判质量瓶颈在于rubric的执行方式（如何提示模型应用标准），而HD-Eval的路径假设瓶颈在于rubric的结构本身（标准是否足够细粒度且与人类偏好对齐）。后续研究在两条路径上均有深化：提示工程路径演化出实例级checklist和原子化rubric等新范式（将在3.2节讨论），而标准分解路径则催生了自主rubric生成的研究（将在3.2节讨论）。值得注意的是，两条路径并非互斥——理想状态下，优化的rubric结构需要配合优化的应用提示才能最大化评判质量。然而，如3.3节将揭示的，无论rubric结构如何优化，rubric文本本身可能携带与评判结果耦合的"artifact"信号，这一发现对两条路径的有效性都构成了潜在挑战。

### 3.2 原子化Rubric与实例级Checklist：约束LLM评判的新范式

进入2025至2026年，rubric设计出现了"原子化"和"二元化"的明确趋势。这一趋势的核心思想是将复杂的评估任务分解为离散的、可独立判断的原子问题，每个问题仅评估一个具体要求并以TRUE/FALSE二元判断作答，从而降低评判模型的推理负荷和评分方差。RocketEval（ICLR 2025）是这一趋势的代表性工作，其核心思想是将评估任务重新构造为使用实例特定checklist的多面问答 [[5](https://www.aminer.cn/pub/67ce4b40163c01c850b7d2e7)]。研究者发现，轻量级与强大LLM在评估任务中的性能差距主要源于其进行全面分析的能力不足，而这不容易通过思维链等技术提升。RocketEval的流程包括三个步骤：为每个实例创建checklist、由轻量级LLM对checklist项进行评分、对checklist项重新加权以与监督标注对齐。使用Gemma-2-2B作为judge的RocketEval达到了与人类偏好0.965的高相关度，与GPT-4o相当，同时在大规模评估场景中成本降低超过50倍。该方法有效解决了轻量级LLM作为judge时面临的高不确定性和位置偏差问题。

原子化rubric设计的实践指南进一步系统化了这一理念。有实践指南提出将rubric视为"形式化规范"，强调四条核心原则：保持问题原子性和独立性，将复合要求拆分为离散的TRUE/FALSE问题；约束评判者使用客观事实而非主观推理，使用RFC 2119术语编写形式化规范；仅评判要求的内容，rubric必须与prompt对齐；通过人类专家手动评分建立"golden set"基线进行校准。该指南的核心理念是：通过约束评判者评估严格的客观布尔事实来减少幻觉和不一致性，使得甚至可以使用更小更快的模型进行评分。尽管这些实践指南来自工业实践而非同行评审研究，但其原则与RocketEval的学术发现高度一致——两者都强调将复杂评分任务分解为原子化判断的策略可以显著提升评判可靠性。

AutoRubric框架进一步将原子化rubric的理念系统化为可复用的开源工具。该框架采用分析型rubric与二元评分作为默认配置，旨在将rubric和judge的选择显式化、可复用和可审计 [[22](https://scale.stanford.edu/ai/repository/autorubric-unified-framework-rubric-based-llm-evaluation)]。AutoRubric在教育评估、深度研究评估和聊天机器人质量评估三个基准上进行了评估，并建议使用多样化judge的集成来提升评估的鲁棒性。该框架的提出表明rubric-based评估正在从经验性实践向系统化方法论演进——rubric不再被视为一次性编写的评估指令，而是需要显式管理、可审计和可迭代改进的评估资产。

然而，LLM能否自主生成可靠的评估rubric是一个尚未充分验证的问题。GER-Eval框架（EACL 2026 Findings）系统研究了这一问题，其两阶段设计——rubric生成（模型根据任务描述生成评估标准）和rubric应用（使用生成的rubric对候选输出评分）——覆盖4个NLG基准和5个模型 [[23](https://aclanthology.org/2026.findings-eacl.335.pdf)]。研究发现LLM能够可靠地生成可解释且与人类rubric对齐率超过80%的评估标准，模型应用自身生成的rubric时表现出强内部一致性——zero-shot与few-shot之间的一致率通常在70-90%，相关系数 > 0.8。然而，与人类判断的对齐在对话型数据集上较好（$\rho \approx 0.8-0.9$），但在SummEval降至约0.5，SumPubMed低于0.3。

GER-Eval的关键发现揭示了rubric迁移的领域依赖性。对话域rubric跨模型泛化良好（ICC $\approx$ 0.7-0.8, $\rho \approx$ 0.7-0.9），但生物医学域几乎不迁移（ICC < 0.2, $\rho$ < 0.3），准确性、覆盖率和术语使用等rubric出现接近零或负相关 [[23](https://aclanthology.org/2026.findings-eacl.335.pdf)]。论文将此概括为模型"在程序上稳定但在语义上有限"——每个模型发展出独特的"评估方言"，捕获了嵌入在语言形式和用法中的一致线索，但在推理事实或内容覆盖方面评估仍然浅薄。这一发现对自主rubric生成的实践构成了重要约束：在对话等以语言流畅性和社交适当性为主要质量维度的任务中，模型自生成的rubric可能足够可靠；但在需要领域知识和事实推理的任务中，自生成rubric的跨模型一致性急剧下降，人类预定义rubric仍是更可靠的选择。

### 3.3 Rubric Artifacts与评判不一致性：形式化规范的张力

原子化、二元化rubric设计被实践证明能有效降低评分方差、提升一致性，但这一范式隐含一个关键假设：rubric文本是中性的评估指令，评判结果源于对被评估内容的真正推理而非rubric文本本身的表面特征。Bagaria等人（2026年8月，预印本）的研究对这一假设提出了根本性质疑，揭示了此前被忽视的"Rubric Artifacts"现象。

该研究设计了一种"rubric probe"实验——仅使用rubric文本训练分类器（PubMedBERT），不给分类器访问任何被评估的候选回复，来预测LLM judge的输出标签。在HealthBench和ResearchRubrics两个基准上，该分类器取得了显著高于随机水平的预测性能：在HealthBench-Eval-Probe上，Gemma模型的准确率达82.6%（F1=0.682），MedLLaMA达90.0%（F1=0.800）[[7](https://arxiv.org/html/2609.02942v1)]。这意味着rubric表述方式与评判结果之间存在耦合——部分评分可以独立于模型输出被预测。研究者进一步进行了反事实一致性分析，结果更为触目惊心：在输出扰动实验中，固定对话和rubric，反转候选回复（从满足到违反rubric），judge仅在37.7%的情况下按预期翻转判决，不一致率高达62.3% [[7](https://arxiv.org/html/2609.02942v1)]。在rubric扰动实验中，固定对话和回复，反转rubric评判标准，judge仅在16.8%（Gemma）和32.2%（LLaMA）的情况下按预期翻转，不一致率分别达83.2%和67.8%。

语义分析进一步揭示了rubric文本携带可预测信号的机制。负向判断的rubric倾向于使用失败标记和否定词汇，正向判断的rubric则使用认知和肯定动词，两类词汇完全不相交。这种词汇分布的不对称性意味着rubric的表述方式本身可能编码了评判结果的可恢复先验——评判模型可能通过rubric文本的表面特征（如否定词频率、失败标记词出现）部分推断预期评判结果，而非完全基于对回复内容的推理。该研究结论是：rubric条件化评估可能无意中编码了与judge输出相关的预测信号，benchmark应旨在消除可恢复的rubric先验。

这一发现与本章前两节讨论的rubric优化路径形成了深层张力。原子化rubric设计的原则之一是使用RFC 2119术语编写形式化规范——"MUST"、"MUST NOT"、"REQUIRED"等。然而，如果rubric文本中否定词和规范性词汇的频率本身与评判结果耦合，那么更严格的形式化规范可能反而强化了rubric artifacts——更多"MUST NOT"可能使评判模型更倾向于给出否定判断，无论回复内容如何。AutoRubric框架强调的rubric显式化与可审计在某种程度上回应了这一挑战：如果rubric选择和评判过程被显式记录和审计，研究者可以检测rubric文本是否携带与结果耦合的先验信号 [[22](https://scale.stanford.edu/ai/repository/autorubric-unified-framework-rubric-based-llm-evaluation)]。然而，审计本身不能消除artifact——它只能发现artifact的存在。消除rubric artifacts可能需要更根本的方法变革，例如对rubric文本进行去相关处理，或设计对rubric表述变化更敏感的评判模型。

综合来看，当前rubric设计与优化领域存在一个核心张力：一方面，原子化、二元化的rubric设计被实践证明能有效降低评分方差、提升一致性和可复用性；另一方面，rubric文本本身可能携带与评分结果耦合的artifact信号，judge对rubric标准变化的敏感度远低于预期。这一张力提示未来的rubric设计不仅需要关注标准的清晰性和原子性，还需要系统性地验证rubric的"信号纯净度"——即评分是否真正源于对回复内容的推理而非rubric文本的表面特征。rubric设计改善了评判准则，但评判模型本身仍需与人类判断对齐，这一判断将本报告的讨论从评估准则设计引向下一章的校准方法。

## 4. 校准方法与人类对齐

### 4.1 Alignment Loop与人类纠正的系统性校准

对齐循环作为系统性校准范式已成为业界共识，其核心理念是：prompt迭代本身无法弥合技术正确与可靠可信之间的差距，必须通过系统化的人类偏好对齐来构建可信赖的评判模型。在技术实现层面，对齐循环的工作流包括三个关键步骤：收集人类纠正——当LLM judge对一条trace打分后，人类审阅者检查判断样本并修正不同意的判断，这些纠正成为测量和改进评估器对齐的ground truth；构建few-shot示例——从人类纠正中构建校准judge的few-shot示例，将正确判断的示例添加到评估器prompt中；随时间测量一致性——持续跟踪评估器与人类专家的一致率，识别分歧类别，用数据而非猜测进行迭代。这一循环被嵌入更广泛的"数据飞轮"机制中：生产trace经分析生成使用模式洞察，洞察路由到数据集形成回归测试，人类纠正改进对齐，更好对齐的评估器为下一轮改进提供更可信信号。在基准表现方面，MT-Bench报告强LLM judge与人类评估者的一致率约为80%，接近人类评估者之间的一致水平。

对齐循环的实践价值在于它将评判模型的校准从一次性提示调优转变为持续的对齐过程。传统的提示工程假设存在一个"最优提示"能够一次性解决评判可靠性问题，而对齐循环承认评估标准会随应用场景演化、评判模型的偏差会在新数据上重新显现，因此需要一个持续的反馈循环来维持对齐质量。然而，对齐循环的实践也面临根本性约束：人类标注成本高昂且不可扩展，标注者的专业水平和一致性直接影响校准质量，且标注过程中的标注者间分歧本身就需要建模而非简单平均。这些约束推动研究界探索更高效的校准范式——从单点对齐到分布对齐、从单语言到多语言、从置信度调整到不确定性建模。

### 4.2 分布对齐与多语言风险约束

传统LLM-as-a-Judge方法主要依赖单点评估——对于每个待评估输出，评判模型给出一个确定性评分。然而，Distributional LLM-as-a-Judge（NeurIPS 2025）指出这种方法忽视了人类评估中固有的多样性和不确定性 [[6](https://www.aminer.cn/pub/691d6d0e163c01c850879bad)]。不同人类标注者可能对同一输出给出不同评分，而单点训练目标无法捕捉这种分布信息，导致信息丢失和评估可靠性下降。该论文提出了一种新型训练框架，显式地将LLM生成的判断分布与人类评估分布对齐。具体方法包括基于KL散度的分布对齐目标函数，结合辅助交叉熵正则化以稳定训练过程；由于人类标注有限，经验人类分布仅是真实分布的噪声估计，因此引入对抗训练确保与真实分布的鲁棒对齐，而非过拟合到不完美的近似 [[6](https://www.aminer.cn/pub/691d6d0e163c01c850879bad)]。实验覆盖多种LLM骨干网络和评估任务，结果表明该框架显著优于现有闭源LLM和传统单点对齐方法，在对齐质量、鲁棒性和评估准确率方面均表现优越。

这一工作的关键创新在于认识到人类评估本身不是确定性的。在对齐循环的实践中，人类标注通常被简化为单一"正确答案"，标注者间分歧被视为噪声而非信号。分布对齐框架则将标注者间分歧建模为人类评估不确定性的自然表达，使评判模型不仅学习"人类给什么分"，还学习"人类评分的分布是什么样的"。这一视角的转变对校准方法的设计具有深远影响：校准的目标不再仅仅是点估计的准确率，而是分布层面的匹配度。对抗训练的引入进一步解决了有限人类标注带来的分布估计噪声问题——经验人类分布可能因标注样本不足而偏离真实分布，对抗训练通过在扰动空间中最小化最坏情况下的分布差异，提供了对这种噪声的鲁棒性保障。

在多语言场景中，校准面临额外的跨语言公平性挑战。多语言LLM judge常对等价答案在不同语言下给出不同分数，损害跨语言公平性。RISC框架（2026）针对这一问题提出了纯黑盒后校准方案，解决了两大实践障碍：跨任务和语言的高偏差异质性，以及黑盒API仅暴露标量输出 [[24](https://www.aminer.cn/pub/6a670a740a96f8c83c9943ec)]。RISC完全黑盒，仅使用标量分数：从观察分数中推导置信信号，执行置信感知调整，仅在证据足够可靠时激活校准。这一设计改善了分数对齐同时限制了对已良好校准案例的退化。在4个评估任务和8种语言上的实验显示，RISC将Qwen2.5-7B-Instruct的平均成对偏差从0.2839降至0.1474，Llama-3-8B-Instruct从0.2095降至0.1264，恶化的语言对极少 [[24](https://www.aminer.cn/pub/6a670a740a96f8c83c9943ec)]。RISC的置信感知调整策略具有普遍的方法论意义：校准不应无条件施加于所有案例，而应仅在模型自身不确定性足够低（即证据可靠）时激活，避免对已良好校准案例的退化。这一原则可推广到非多语言场景的校准设计——任何后校准方法都应包含"何时校准"的条件判断机制，而非对所有输入统一施加校准变换。

### 4.3 不确定性度量与过度自信校准

LLM-as-a-Judge系统普遍存在的过度自信现象是校准研究的核心挑战之一。过度自信指模型预测的置信度显著超过实际正确性，导致可靠性下降。论文《Overconfidence in LLM-as-a-Judge》（2025年8月，预印本）在JudgeBench基准上系统评估了14个前沿模型，采用三种置信度计算方法：Self-Confidence（SC）、Multiple-Prompting（MP）和Logprob置信度 [[25](https://arxiv.org/html/2508.06225v2)]。结果显示过度自信现象普遍存在且严重：在SC设置下，GPT-4o的ECE高达39.25，Mistral-Nemo高达74.22，GPT-4.1-nano为57.03。即使是表现最好的Qwen3-235B-A22B（准确率77.43%），ECE仍为11.78 [[25](https://arxiv.org/html/2508.06225v2)]。这些数字意味着即使是最强的评判模型，其置信度与实际正确率之间仍存在显著差距——在风险感知评估场景中，这种差距可能导致大量错误判断被高置信度地接受，而正确判断被低置信度地丢弃。

为量化这一现象，该论文提出了TH-Score新指标，聚焦于高置信度和低置信度区间，通过平衡这些区间内的预测准确率和覆盖范围来评估。TH-Score的设计动机是传统指标如ECE忽略了对实际应用最关键的高/低置信度区间——在实际部署中，高置信度判断通常被自动接受而低置信度判断被路由至人工审核，因此这两个区间的准确率直接影响系统的实际可靠性。该论文还提出了LLM-as-a-Fuser集成框架，通过专用"fuser" LLM综合多模型判断和批判，实现证据感知聚合。实验显示，LLM-as-a-Fuser（使用Qwen3-235B-A22B作为fuser）达到最高准确率86.29%和最佳校准ECE 6.42%，相比SC设置下的原始模型提升+8.86%准确率和-5.36% ECE [[25](https://arxiv.org/html/2508.06225v2)]。弱模型获益更大：Mistral-Nemo提升+47.14%准确率、-53.73% ECE。这一结果表明集成+批判综合是比简单多数投票更有效的校准策略——fuser不仅聚合多个模型的判断，还综合了各模型的批判理由，使最终判断基于更全面的证据。

在不确定性度量的选择上，哪种度量与人类群体级不确定性最相关是一个对校准实践有直接影响的问题。《Investigating Human-Aligned Large Language Model Uncertainty》（FLAIRS 2026）的研究调查了多种不确定性度量以识别与人类群体行为相关的度量 [[26](https://www.aminer.cn/pub/67d8d421163c01c8506385f4)]。研究发现，贝叶斯度量和熵度量的变体——top-k熵——倾向于随模型规模增长而与人类行为一致。同时，某些强度量随模型规模增大在人类相似性方面下降，但通过多元线性回归，组合多种不确定性度量可以提供可比的人类对齐效果，同时减少对模型规模的依赖 [[26](https://www.aminer.cn/pub/67d8d421163c01c8506385f4)]。这一发现对对齐循环的校准有直接意义：选择正确的不确定性度量对于构建人类对齐的置信度驱动评估流水线至关重要。更重要的是，组合多种度量减少模型规模依赖的发现暗示——单一不确定性度量可能在某些模型规模上与人类对齐而在其他规模上不对齐，而度量组合提供了跨规模的稳健性。

不确定性量化与校准方法的最新进展进一步丰富了校准工具箱。Tao等人评估了80个模型（0.6B-671B），发现语言verbal uncertainty（LVU）在校准和判别力上持续优于token probability-based uncertainty（TPU）和数值verbal uncertainty（NVU），且高准确度不意味着可靠的不确定性 [[27](https://www.aminer.cn/pub/683d047f163c01c850b252b5)]。这一发现打破了"高准确率模型自然具有可靠不确定性估计"的假设——准确率与不确定性校准是正交的两个维度，需要在评估中分别考察。Bani-Harouni等人提出基于对数评分规则的RL方法直接微调LLM表达校准置信度，同时惩罚过度自信和自信不足，无需额外微调即可泛化到未见任务 [[28](https://www.aminer.cn/pub/67c7b867163c01c8507b6922)]。Stengel-Eskin等人的LACIE方法通过listener-aware finetuning建模听众是否接受答案，使人类评估中错误答案接受率降低47%，模型在不确定时更倾向于对冲表达 [[29](https://www.aminer.cn/pub/665d23a101d2a3fbfc1f14a0)]。这些方法从不同角度——奖励设计、听众建模——改善置信度校准，共同指向一个核心原则：校准不仅是调整置信度数值，更是改变模型在不确定条件下的行为模式。

综合来看，校准方法的技术路线呈现从prompt工程到人类纠正few-shot校准到集成聚合到分布对齐训练到黑盒后校准的多元化发展格局。过度自信是核心挑战，而外部校准依赖人类标注信号注入。然而，评判模型自身是否可通过反思与自洽机制内生性地提升可靠性，而不依赖外部人类信号？这一问题将本报告的讨论引向第5章的反思技术与去偏差策略。

![图](images/figure_2.png)

**图 2：主流LLM评判模型的过度自信现象（ECE值越高表示过度自信越严重）**

## 5. 反思自洽与去偏差技术：演进、系统比较与开放挑战

### 5.1 Meta-Judge范式与多层评判机制

从单一judge到多层judge的架构演进是LLM-as-a-Judge可靠性提升的重要方向。Silva等人(2026)的综述系统梳理了从LLM-as-a-Judge到LLM-as-a-Meta-Judge的演进，Meta-judge的核心思路是：不直接评判模型输出，而是评估其他LLM法官产生的评分、理由或批评——即"法官的法官" [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。Meta-judge可以检测有缺陷的推理、识别系统性偏差，甚至修正判断。这一范式沿六个维度组织文献：概念基础、元判断机制、对齐训练方法、评估、局限性与失败模式、未来方向。

在具体实现上，多种Meta-Judge架构已被提出并验证。Li等人的多智能体框架让多个LLM独立或协作评分后通过加权平均、多数投票或小组讨论聚合，在JudgeBench上精度提升超15%，比单agent基线提升8% [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。Wu等人的Meta-Rewarding框架让单个LLM在actor/judge/meta-judge三角色间迭代轮换，生成偏好对通过DPO优化judge，AlpacaEval 2胜率从22.9%提升至39.4%，Arena-Hard从20.6%提升至29.1% [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。Trivedi等人的Self-Rationalization方法让模型为同一输入生成多个带理由的独立判断，通过DPO精调实现62%胜率。Ma等人则探索了Select和Conclude两种元判断设置——前者从判断池中选择最强判断，后者将所有判断综合为单一最终决策。

然而，Meta-Judge范式面临一个根本性的局限：共享模型偏差。综述明确指出，使用多层LLM互相评判的价值有限，因为这些模型共享相似的偏差，元判断主要检查内部一致性而非真值 [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。这一局限的含义是深远的：如果元判断模型与初级判断模型来自同一模型家族或共享相似的训练数据，那么元判断可能只是在同质化的偏差空间内进行自洽性检查，而非对真值的独立验证。此外，成本高企、prompt敏感性强，以及位置偏差虽可缓解但无法完全消除，都是Meta-Judge范式尚未解决的实践挑战。Haldar与Hockenmaier的自不一致研究为这一局限提供了补充证据：使用Krippendorff's Alpha作为机会校正的一致性度量，发现即便最强模型在MT-Bench上的Alpha也仅0.563，远低于0.8的可接受阈值，且关闭采样虽可消除变异但反而降低性能，存在自一致性与性能之间的trade-off。这表明LLM judge的自不一致问题是结构性的，prompt工程效果有限，需要统计聚合才能有效缓解。

### 5.2 去偏差策略的系统比较与组合优化

在去偏差技术的横向比较方面，Soumik(2026, TMLR)的论文对9种去偏差策略进行了迄今最全面的实证比较，涵盖5个judge模型、3个基准和4种偏差类型 [[30](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06)]。核心实践发现具有直接的操作指导价值：搭配Combined Budget策略的Gemini 2.5 Flash达到最高一致性（71.0%, $\kappa$=0.549, $p<0.0001$），每次评估成本约$0.001，比最强前沿配置（Claude Sonnet 4 + 同策略, 69.5%, ~$0.015/次）便宜约15倍 [[30](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06)]。这一发现的重要实践含义是：组合去偏策略可以让中端模型在一致性上超越前沿模型，同时大幅降低评估成本——这对大规模评估场景的可行性具有决定性影响。

在偏差类型方面，该研究揭示了此前被低估的偏差格局。风格偏差是主导偏差（基线0.10-0.76，主要偏好markdown而非纯文本），远超位置偏差（$\leq$ 0.04），却受到了最少的研究关注 [[30](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06)]。冗长偏差具有异质性——Llama/Gemini Pro/Gemini Flash偏好更长回答（+0.24到+0.44），Claude Sonnet 4相反（-0.12, 偏好简洁），GPT-4o基本中性（-0.04）。在Holm-Bonferroni校正后，Claude S8（+11.5pp）、Flash S8（+7.5pp）、Claude S5（+7.3pp）的去偏差效果仍统计显著。这些发现与第2章的偏差实证形成了互补——第2章揭示了偏差的存在与机制，而本节的技术比较回答了"哪些去偏策略在什么条件下最有效"的实践问题。

不确定性估计与校准方法的综述进一步呈现了去偏差技术的全貌。Tao等人的评估发现LVU持续优于TPU和NVU，且高准确度不意味着可靠的不确定性 [[27](https://www.aminer.cn/pub/683d047f163c01c850b252b5)]——这一发现在去偏差策略选择的语境下意味着：一个高准确率的评判模型可能在不确定性估计上严重不可靠，从而在需要置信度驱动的去偏策略中表现不佳。Bani-Harouni等人的RL校准方法通过奖励设计同时惩罚过度和不足自信 [[28](https://www.aminer.cn/pub/67c7b867163c01c8507b6922)]，Stengel-Eskin等人的LACIE通过listener-aware finetuning使错误答案接受率降低47% [[29](https://www.aminer.cn/pub/665d23a101d2a3fbfc1f14a0)]。这些方法与第4章讨论的校准技术形成呼应——不确定性校准既是评判模型校准的组成部分，也是去偏差策略的设计基础。当评判模型的置信度可靠时，低置信度判断可以被自动标记为需要进一步审查或聚合，这本身就是一种去偏差机制。

综合来看，去偏差技术的发展呈现两个明确趋势。第一是组合优化：单一去偏策略的效果有限且偏差类型依赖，但策略组合（如Combined Budget策略）可以实现超越单一策略和更强模型的效果。第二是从启发式去偏到统计校准的演进：早期去偏策略多为启发式规则（如交换位置取平均、长度归一化），而近期工作引入了回归校正、分布对齐和不确定性量化等统计方法，使去偏效果可量化、可验证。如第2章所述的RBD框架代表了跨偏差类型联合去偏的框架化路径——RBD-8B在四种偏差类型上平均提升准确率18.5% [[20](https://www.aminer.cn/pub/6833ca05163c01c8505ea141)]，与Soumik的九种策略系统比较形成了方法论层面的互补：前者探索单一框架覆盖多偏差类型，后者探索多策略组合实现整体最优。

### 5.3 开放挑战：多模态评判、多智能体协同与系统级约束

本报告前述各章聚焦于文本模态下的LLM-as-a-Judge偏差、准则设计、校准与反思技术，但若干重要方向尚未得到系统性实证支撑，需在局限性中明确指出。

多模态评判是当前研究覆盖最为薄弱的方向之一。本报告引用的文献几乎全部聚焦于文本生成任务的评估，而图像、视频、音频等多模态输出的评判面临独特的挑战：多模态输出质量的维度更加复杂（如视觉美感、音频清晰度、跨模态一致性等），人类评估者间的一致性在多模态任务中通常更低，且现有rubric设计原则（如原子化二元判断）在多模态场景中的适用性尚未验证。多模态评判模型是否表现出与文本评判相同的位置偏差、冗长偏差和自偏好偏差，以及这些偏差在多模态条件下的表现形式和强度，都是亟需实证研究的问题。

多智能体协同评判是另一个具有实践重要性但缺乏系统性实证的方向。Meta-Judge范式已涉及多智能体架构，但现有研究主要关注同一模型家族内的多角色轮换或同构模型的集成。跨模型家族的多智能体协同——例如使用不同架构、不同训练数据的模型分别评估不同质量维度——可能缓解共享模型偏差问题，但也会引入新的挑战：不同模型对同一质量维度的理解可能不一致（如第3章讨论的"评估方言"），多智能体聚合策略的设计需要考虑模型间的系统性差异而非简单多数投票。系统级延迟与成本约束在实际部署中至关重要——Soumik的研究已显示组合策略可以将评估成本降低15倍 [[30](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06)]，但多智能体架构的通信开销和推理延迟在实时评估场景中可能构成瓶颈。当前文献对这些系统级约束的讨论仍然有限。

不同模型架构差异对评判可靠性的影响也是一个需要更深入研究的方向。GER-Eval的研究已揭示闭源模型（如GPT-4o）在rubric生成和应用上普遍优于开源模型（如Llama），但这种差异的根因——是参数规模、训练数据、对齐策略还是架构本身的差异——尚未被分离 [[23](https://aclanthology.org/2026.findings-eacl.335.pdf)]。第2章讨论的自偏好偏差根因争议也涉及模型架构：困惑度根因说和认知负荷分解说可能在不同架构上的解释力不同。对模型架构差异的系统研究将为评判模型的选择提供更可靠的依据。

本报告在引用若干证据时需注明局限性。对齐循环的技术框架主要来自技术指南而非同行评审研究，其具体效果数据（如80%一致率）应作为背景参考而非严格学术证据。过度自信现象的研究（第4章引用的arXiv:2508.06225v2）为预印本，其TH-Score指标和LLM-as-a-Fuser框架的效果仍需独立验证。原子化rubric四原则（第3章）同样来自实践指南而非同行评审，其有效性在不同任务和模型上的泛化性有待系统性验证。Rubric Artifacts研究（第3章引用的arXiv:2609.02942v1）亦为预印本，其反事实扰动实验的设计和结论需在更广泛的任务和模型上复现。自偏好偏差的全自动化量化框架（第2章引用的预印本）提出的认知负荷分解策略效果（降低SPB 31.5%）同样需要在更多任务域上验证。这些证据较弱的发现在本报告中被用于构建论证框架和提出研究假设，但其具体数值和结论不应被引用为确定性的学术共识。

LLM-as-a-Judge的可靠性提升需要偏差诊断、准则设计、校准方法和反思技术的协同推进。单一维度的优化——无论是更优的rubric、更强的校准信号还是更多层的反思机制——都不足以彻底解决评判可靠性问题。共享模型偏差、rubric artifacts和过度自信现象等发现共同指向一个核心认识：LLM-as-a-Judge的可靠性不是一个可以通过单一技术突破解决的问题，而是一个需要在评估准则、校准信号和反思机制之间建立系统平衡的持续工程挑战。未来的研究需要在多模态评判、多智能体协同和系统级约束等方向上填补实证空白，同时建立不同去偏差技术和校准方法之间的定量基准比较，为实践者提供可操作的模型选择和策略配置指导。

## 结论

本报告系统梳理了LLM-as-a-Judge范式在评判可靠性与一致性方面的研究进展，围绕系统性偏差实证、Rubric设计、校准方法与反思技术四个核心维度展开论证。核心发现可归纳为以下几方面。

第一，系统性偏差的普遍性与异质性。位置偏差、冗长偏差、自偏好偏差和同意偏差在不同任务和模型上表现出系统性存在，但偏差方向、强度和表现形式高度依赖具体任务与模型组合 [[2](https://www.aminer.cn/pub/66b18cbe01d2a3fbfc7bd09e)] [[3](https://www.aminer.cn/pub/66835f4601d2a3fbfc717fd7)] [[17](https://www.aminer.cn/pub/672195e901d2a3fbfc6ab4b4)]。在招聘评估和医疗分诊等高风险场景中，位置偏差可能产生直接的现实危害 [[10](https://www.aminer.cn/pub/6abafb6225ef7be5fbbf08dd)] [[11](https://www.aminer.cn/pub/699d226e9be8eb7c4b17e971)]。同意偏差揭示了评判模型在识别错误输出方面的严重不足（真阴性率低于25%），而这一缺陷在标准精度指标下不可见 [[4](https://www.aminer.cn/pub/68eeef5e163c01c850f75191)]。跨偏差类型联合去偏的框架化路径已显示出超越单一策略的效果 [[20](https://www.aminer.cn/pub/6833ca05163c01c8505ea141)]，但通用去偏策略的设计仍面临根本性挑战。

第二，Rubric设计的进步与张力。原子化与二元化Rubric设计被实践证明能有效降低评分方差并提升一致性 [[5](https://www.aminer.cn/pub/67ce4b40163c01c850b7d2e7)]，但Rubric文本本身可能携带与评判结果耦合的预测信号，评判模型对Rubric标准变化的敏感度远低于预期 [[7](https://arxiv.org/html/2609.02942v1)]。自主Rubric生成在对话域表现可靠但在需要领域知识的任务中跨模型一致性急剧下降 [[23](https://aclanthology.org/2026.findings-eacl.335.pdf)]。这一发现提示未来的Rubric设计不仅需要关注标准的清晰性，还需系统验证Rubric的信号纯净度。

第三，校准方法的多元化演进。校准技术从提示工程到人类纠正的系统性对齐循环，拓展至分布对齐训练与不确定性量化。分布对齐框架将标注者间分歧建模为人类评估不确定性的自然表达，校准目标从点估计准确率转向分布层面的匹配度 [[6](https://www.aminer.cn/pub/691d6d0e163c01c850879bad)]。过度自信现象普遍且严重——即使最强的评判模型也存在显著置信度与正确率差距 [[25](https://arxiv.org/html/2508.06225v2)]。语言verbal不确定性在校准上持续优于基于token概率的度量，且高准确率与可靠不确定性估计是正交的两个维度 [[27](https://www.aminer.cn/pub/683d047f163c01c850b252b5)]。置信感知的校准策略表明，校准不应无条件施加于所有案例，而应仅在证据足够可靠时激活 [[24](https://www.aminer.cn/pub/6a670a740a96f8c83c9943ec)]。

第四，反思技术的进展与局限。Meta-Judge范式通过多层评判机制可提升评估精度，但受共享模型偏差制约，元判断主要检查内部一致性而非真值 [[8](https://www.aminer.cn/pub/697813e09be8eb7c4bb35142)]。九种去偏策略的系统比较揭示，组合去偏策略可使中端模型在一致性上超越前沿模型，同时大幅降低评估成本 [[30](https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06)]。自不一致问题是结构性的，prompt工程效果有限，需要统计聚合才能有效缓解。

在局限性与信息缺口方面，本报告需指出若干证据层面约束。对齐循环的技术框架主要来自技术指南而非同行评审研究，其效果数据应作为背景参考而非严格学术证据。过度自信现象与Rubric Artifacts的研究均为预印本，其具体指标和结论需在更广泛的任务和模型上独立验证。自偏好偏差的认知负荷分解策略效果同样需在更多任务域上复现。此外，多模态评判、跨模型家族的多智能体协同以及系统级延迟与成本约束等方向尚未得到系统性实证支撑，当前文献对这些方向的讨论仍然有限。

展望未来，LLM-as-a-Judge的可靠性提升需要偏差诊断、准则设计、校准信号与反思机制的协同推进。共享模型偏差、Rubric Artifacts和过度自信现象等发现共同指向一个核心认识：评判可靠性不是可以通过单一技术突破解决的问题，而是一个需要在评估准则、校准信号和反思机制之间建立系统平衡的持续工程挑战。未来的研究应在多模态评判、多智能体协同和系统级约束等方向上填补实证空白，同时建立不同去偏差技术与校准方法之间的定量基准比较，为实践者提供可操作的模型选择与策略配置指导。

> ⚠️ 注：本报告中「LLM-as-a-Fuser的准确率提升」在不同章节出现不一致的数值（+8.86%、提升至86.29%），引用时请以原始信源为准。

## 参考文献

[1] Yang Liu, Dan Iter, Yichong Xu, Shuohang Wang, Ruochen Xu, and Chenguang Zhu. "G-Eval: NLG Evaluation Using GPT-4 with Better Human Alignment", EMNLP 2023 (2023). URL: https://www.aminer.cn/pub/6424fe3390e50fcafd78b6f4

[2] Lin Shi, Chiyu Ma, Wenhua Liang, Weicheng Ma, and Soroush Vosoughi. "Judging the Judges: A Systematic Investigation of Position Bias in Pairwise Comparative Assessments by LLMs.", ICLR 2025. URL: https://www.aminer.cn/pub/66b18cbe01d2a3fbfc7bd09e

[3] Zhengyu Hu, Linxin Song, Jieyu Zhang, Zheyuan Xiao, Tianfu Wang, Zhengyu Chen, Nicholas Jing Yuan, Jianxun Lian, Kaize Ding, and Hui Xiong. "Explaining Length Bias in LLM-Based Preference Evaluations", EMNLP 2025 Findings of the Association for Computational Linguistics: EMNLP 2025 (2025): 6763–6794. URL: https://www.aminer.cn/pub/66835f4601d2a3fbfc717fd7

[4] Suryaansh Jain, Umair Z. Ahmed, Shubham Sahai, and Ben Leong. "Beyond Consensus: Mitigating the Agreeableness Bias in LLM Judge Evaluations", ICLR 2026. URL: https://www.aminer.cn/pub/68eeef5e163c01c850f75191

[5] Tianjun Wei, Wei Wen, Ruizhi Qiao, Xing Sun, and Jianghong Ma. "RocketEval: Efficient Automated LLM Evaluation Via Grading Checklist", ICLR 2025. URL: https://www.aminer.cn/pub/67ce4b40163c01c850b7d2e7

[6] Luyu Chen, Zeyu Zhang, Haoran Tan, Quanyu Dai, Hao Yang, Zhenhua Dong, and Xu Chen. "Distributional LLM-as-a-Judge", NeurIPS 2025. URL: https://www.aminer.cn/pub/691d6d0e163c01c850879bad

[7] Concerning Rubric Artifacts in LLM-based Automated Text Generation Evaluation. URL: https://arxiv.org/html/2609.02942v1

[8] Hugo Silva, Mateus Mendes, and Hugo Gonçalo Oliveira. "Meta-Judging with Large Language Models: Concepts, Methods, and Challenges", Computing Research Repository abs/2601.17312 (2026). URL: https://www.aminer.cn/pub/697813e09be8eb7c4bb35142

[9] Yixin Liu, Pengfei Liu, and Arman Cohan. "On Evaluating LLM Alignment by Evaluating LLMs As Judges", NeurIPS 2025. URL: https://www.aminer.cn/pub/691d6b2f163c01c85085f952

[10] Loubna Aminou, Abdelaziz Daaif, Maha Soulami, and Mohamed Youssfi. "Measuring Position Bias in LLM-as-a-Judge for Hiring", 2026 16th International Conference on Advanced Computer Information Technologies (ACIT) (2026): 1413-1418. URL: https://www.aminer.cn/pub/6abafb6225ef7be5fbbf08dd

[11] Ulrika Wickenberg-Bolin, Katie Cohen, Helena Björnesjö, and Agnes Tegen. "Position Bias in LLMs for Critical Decision Support: A Case Study on Multiple Casualty Triage.", Lecture Notes in Computer Science (2026): 529-541. URL: https://www.aminer.cn/pub/699d226e9be8eb7c4b17e971

[12] Özgür Çelik. "Lost in the Middle? Examining Scoring Reliability and Position Bias in LLM-based Automated Essay Scoring", Education and Information Technologies (2026): 1-19. URL: https://www.aminer.cn/pub/69fc4f750a96f8c83c732015

[13] Hyeonji Kim, Sujeong Oh, and Sanghack Lee. "Mitigating Length Bias in RLHF Through a Causal Lens", AAAI 2026 40.21 (2026): 17517-17525. URL: https://www.aminer.cn/pub/691bdbe1163c01c850d3cb74

[14] Kangwen Zhao, Jianfeng Cai, Jinhua Zhu, Ruopei Sun, Dongyun Xue, Wengang Zhou, Li Li, and Houqiang Li. "Bias Fitting to Mitigate Length Bias of Reward Model in RLHF", ACL 2026 (2026): 2912–2927. URL: https://www.aminer.cn/pub/682be3c4163c01c850f4a2de

[15] Zeyu Huang, Zihan Qiu, Zili Wang, Edoardo Ponti, and Ivan Titov. "Post-hoc Reward Calibration: A Case Study on Length Bias", ICLR 2025. URL: https://www.aminer.cn/pub/66f619a301d2a3fbfcdc604f

[16] Hongli Zhou, Hui Huang, Yunfei Long, Bing Xu, Conghui Zhu, Hailong Cao, Muyun Yang, and Tiejun Zhao. "Mitigating the Bias of Large Language Model Evaluation", Chinese Computational Linguistics (2024): 451-462. URL: https://www.aminer.cn/pub/66f4cd3401d2a3fbfcbfab6c

[17] Koki Wataoka, Tsubasa Takahashi, and Ryokan Ri. "Self-Preference Bias in LLM-as-a-Judge", ICLR 2025. URL: https://www.aminer.cn/pub/672195e901d2a3fbfc6ab4b4

[18] Jinming Yang, Zheng Hu, Chuxian Qiu, Zhenyu Deng, Xinshan Jiao, and Tao Zhou. "Quantifying and Mitigating Self-Preference Bias of LLM Judges", arXiv preprint arXiv 2604.22891 (2026). URL: https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31a4d

[19] José Pombal, Ricardo Rei, and Andre Martins. "Self-Preference Bias in Rubric-Based Evaluation of Large Language Models", COLM 2026. URL: https://www.aminer.cn/pub/69d6f9de9be8eb7c4b04628c

[20] Haoyan Yang, Runxue Bao, Cao Xiao, Jun Ma, Parminder Bhatia, Shangqian Gao, and Taha Kass-Hout. "Any Large Language Model Can Be a Reliable Judge: Debiasing with a Reasoning-based Bias Detector", NeurIPS 2025. URL: https://www.aminer.cn/pub/6833ca05163c01c8505ea141

[21] Yuxuan Liu, Tianchi Yang, Shaohan Huang, Zihan Zhang, Haizhen Huang, Furu Wei, Weiwei Deng, Feng Sun, and Qi Zhang. "HD-Eval: Aligning Large Language Model Evaluators Through Hierarchical Criteria Decomposition", PROCEEDINGS OF THE 62ND ANNUAL MEETING OF THE ASSOCIATION FOR COMPUTATIONAL LINGUISTICS, VOL 1 LONG PAPERS (2024): 7641-7660. URL: https://www.aminer.cn/pub/65dd4f8013fb2c6cf66f9dfd

[22] A Unified Framework For Rubric-Based Llm Evaluation. URL: https://scale.stanford.edu/ai/repository/autorubric-unified-framework-rubric-based-llm-evaluation

[23] 2026.findings-eacl.335.pdf. URL: https://aclanthology.org/2026.findings-eacl.335.pdf

[24] Dian Kong, and Chongjun Wang. "RISC: Black-Box Risk-Bounded Score Calibration for Multilingual LLM-as-a-Judge", Lecture Notes in Computer Science (2026): 515-526. URL: https://www.aminer.cn/pub/6a670a740a96f8c83c9943ec

[25] Overconfidence in LLM-as-a-Judge: Diagnosis and Confidence-Driven Solution. URL: https://arxiv.org/html/2508.06225v2

[26] Kyle Moore, Jesse Roberts, Daryl Watson, and Pamela Wisniewski. "Investigating Human-Aligned Large Language Model Uncertainty", International Florida Artificial Intelligence Research Society Conference (2026). URL: https://www.aminer.cn/pub/67d8d421163c01c8506385f4

[27] Linwei Tao, Yi-Fan Yeh, Minjing Dong, Tao Huang, Philip Torr, and Chang Xu. "Revisiting Uncertainty Estimation and Calibration of Large Language Models", alphaxiv (2025). URL: https://www.aminer.cn/pub/683d047f163c01c850b252b5

[28] David Bani-Harouni, Chantal Pellegrini, Paul Stangel, Ege Özsoy, Kamilia Zaripova, Nassir Navab, and Matthias Keicher. "Rewarding Doubt: A Reinforcement Learning Approach to Calibrated Confidence Expression of Large Language Models", ICLR 2026. URL: https://www.aminer.cn/pub/67c7b867163c01c8507b6922

[29] Elias Stengel-Eskin, Peter Hase, and Mohit Bansal. "LACIE: Listener-Aware Finetuning for Calibration in Large Language Models", NeurIPS 2024 (2024). URL: https://www.aminer.cn/pub/665d23a101d2a3fbfc1f14a0

[30] Sadman Kabir Soumik. "Judging the Judges: A Systematic Evaluation of Bias Mitigation Strategies in LLM-as-a-Judge Pipelines", TMLR. URL: https://www.aminer.cn/pub/69f0083a9be8eb7c4bd31c06



*本报告基于AMiner数据与网络搜索结果于2026年10月15日生成  报告类型:文献综述  模型：旗舰版*

*(注:本文部分内容可能由AI生成)*